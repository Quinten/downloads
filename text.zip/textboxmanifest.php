<?php
header("Content-Type: text/cache-manifest;");
echo "CACHE MANIFEST\r\n";
echo "CACHE:\r\n";
echo "index.html\r\n";
?>